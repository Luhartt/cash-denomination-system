from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
from Utils import Utils
from session import Session

class ReplenishCashInventory:
    def __init__(self, root):
        self.root = root
        super().__init__(root, "Check Inventory") 
        super().setup_background()
        super().setup_fonts()
        
        
        
def main():
    
    root = tk.Tk()
    app = ReplenishCashInventory(root)
    root.mainloop()

if __name__ == "__main__":
    main()